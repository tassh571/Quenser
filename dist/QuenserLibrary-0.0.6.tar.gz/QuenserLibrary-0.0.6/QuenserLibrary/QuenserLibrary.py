from robot.api.deco import keyword

class QuenserLibrary:
    def PrintTEST(self):
        """Hello World

        If the element does not support text input an error
        will be raised.
        """
        print("Hello World test")
