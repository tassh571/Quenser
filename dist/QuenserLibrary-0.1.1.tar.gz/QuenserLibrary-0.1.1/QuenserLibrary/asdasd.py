# -*- coding: utf-8 -*-
#asdasd.py

from robot.api.deco import keyword


class asdasd:
    def asddsa(self):
        """ พิมพ์ข้อความ 'Hello, world!' ลงในคอนโซล แบบไม่ได้แอดคีย์ """
        print("Hello, world! เทสภาษาไทย")

    @keyword("ewqeqw")
    def dsa(self):
        """ พิมพ์ข้อความ 'Hello, world!' ลงในคอนโซล แบบแอดคีย์ """
        print("Hello, world! Test keyword='Hello, world!'")
