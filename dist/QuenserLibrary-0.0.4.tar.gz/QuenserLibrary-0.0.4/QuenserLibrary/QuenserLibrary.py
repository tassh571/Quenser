from robot.api.deco import keyword

class QuenserLibrary:
    @keyword("Quenser")
    def quenser_keyword(self):
        print("Hello, world!")
