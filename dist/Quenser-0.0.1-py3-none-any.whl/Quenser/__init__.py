# __init__.py

from .example_module import say_hello
